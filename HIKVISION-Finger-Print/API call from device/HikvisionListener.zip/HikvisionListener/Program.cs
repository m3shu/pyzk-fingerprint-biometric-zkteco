using System.Text;
using System.Text.Json;
using System.Xml.Linq;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapPost("/", HandleEvent);
app.MapPost("/api/hikvision/event", HandleEvent);

Console.WriteLine("Hikvision Listener running on http://192.168.1.37:5000");

app.Run("http://192.168.1.37:5000");


async Task<IResult> HandleEvent(HttpRequest request)
{
    Console.WriteLine("\n==============================");
    Console.WriteLine("HIKVISION EVENT RECEIVED");
    Console.WriteLine("Content-Type: " + request.ContentType);
    Console.WriteLine("==============================");

    string raw;

    using (var reader = new StreamReader(request.Body, Encoding.UTF8))
    {
        raw = await reader.ReadToEndAsync();
    }

    Console.WriteLine("RAW BODY:");
    Console.WriteLine(raw);
    Console.WriteLine("==============================");

    var result = HandleJson(raw) ?? HandleXml(raw);

    if (result != null)
    {
        Console.WriteLine("EVENT SUCCESS:");
        Console.WriteLine(JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));

        return Results.Json(new
        {
            status = "success",
            message = "Valid Hikvision event received",
            data = result
        });
    }

    Console.WriteLine("Ignored heartbeat or unknown data");

    return Results.Json(new
    {
        status = "ignored"
    });
}



Dictionary<string, object>? HandleJson(string json)
{
    try
    {
        if (!json.Trim().StartsWith("{"))
            return null;

        var doc = JsonDocument.Parse(json);

        if (!doc.RootElement.TryGetProperty("event", out var eventNode))
            return null;

        if (!eventNode.TryGetProperty("EventNotification", out var notification))
            return null;

        if (!notification.TryGetProperty("AccessControllerEvent", out var access))
            return null;

        if (!access.TryGetProperty("employeeNoString", out var employee))
            return null;

        return new Dictionary<string, object>
        {
            ["employee"] = employee.GetString() ?? "",
            ["name"] = access.GetProperty("name").GetString() ?? "",
            ["verify_mode"] = access.GetProperty("currentVerifyMode").GetString() ?? "",
            ["time"] = DateTime.Now.ToString("O")
        };
    }
    catch
    {
        return null;
    }
}



Dictionary<string, object>? HandleXml(string xml)
{
    try
    {
        if (!xml.Trim().StartsWith("<"))
            return null;

        var doc = XDocument.Parse(xml);

        var employee = doc.Descendants("employeeNoString").FirstOrDefault()?.Value;

        if (string.IsNullOrEmpty(employee))
            return null;

        return new Dictionary<string, object>
        {
            ["employee"] = employee,
            ["name"] = doc.Descendants("name").FirstOrDefault()?.Value ?? "",
            ["verify_mode"] = doc.Descendants("currentVerifyMode").FirstOrDefault()?.Value ?? "",
            ["time"] = DateTime.Now.ToString("O")
        };
    }
    catch
    {
        return null;
    }
}